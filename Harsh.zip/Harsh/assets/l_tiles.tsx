<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="l_tiles" tilewidth="30" tileheight="30" spacing="2" margin="1" tilecount="880" columns="40">
 <image source="assets/picture.jpeg" width="1280" height="720"/>
</tileset>

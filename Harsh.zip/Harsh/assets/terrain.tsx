<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="WhatsApp Image 2022-12-20 at 19.59.36" tilewidth="32" tileheight="32" tilecount="777" columns="37">
 <image source="WhatsApp Image 2022-12-20 at 19.59.36.jpg" width="1200" height="675"/>
</tileset>
